package org.ctlv.proxmox.manager;


public class ManagerMain {

	public static void main(String[] args) throws Exception {
		
		// to do
	}

}